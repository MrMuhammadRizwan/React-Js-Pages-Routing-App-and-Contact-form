import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import Home from './Home';
import About from './About';
import Contact from './Contact';
// import {Bootstrap, ControlLabel, FormControl, Grid, HelpBlock, Row, Col, Button, Navbar, Nav, NavItem, FormGroup, FieldGroup} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css'; 
import 'bootstrap/dist/css/bootstrap-theme.css';
import { BrowserRouter, Route} from 'react-router-dom';


ReactDOM.render(
<BrowserRouter>
    <div>
        <Route path="/" component={App} />
        <Route path="/Home" component={Home} />
        <Route path="/About" component={About} />
        <Route path="/Contact" component={Contact} />
    </div>
</BrowserRouter>, document.getElementById('root'));
//default render  ReactDOM.render(<App />, document.getElementById('root'));
registerServiceWorker();
