import React, { Component } from 'react';
import './App.css';
import {Navbar, Nav} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css'; 
import 'bootstrap/dist/css/bootstrap-theme.css';
import {Link } from 'react-router-dom';

class App extends Component {
  render() {
    return (
      <div className="">
        <div className="container">
          <div className="menu">



            
            {
              /*
              
              <Navbar inverse collapseOnSelect>
              <Navbar.Header>
                <Navbar.Brand>
                  LOGO!
                </Navbar.Brand>
                <Navbar.Toggle />
              </Navbar.Header>
              <Navbar.Collapse>
                <Nav>
                  <li>
                    <Link to="/Home">
                     Home
                    </Link></li>
                  <li>
                    <Link to="/About">
                      About
                    </Link></li>
                  <li><Link to="/Contact">
                      Contact
                    </Link></li>
                </Nav>
              </Navbar.Collapse>
            </Navbar>*/}
          </div>
            
            <div className="o-p">
              {this.props.children}
              {/*<Home/>
              <About/>
              <Contact/>*/}
            </div>
            
            
          
        </div>
      </div>
    );
  }
}

export default App;
